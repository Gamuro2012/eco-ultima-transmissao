# ECO: A Última Transmissão — Fabric 26.3

**Versão do projeto:** 0.3.0  
**Minecraft:** Java Edition 26.3  
**Loader:** Fabric Loader 0.19.5  
**Java para compilar:** JDK 25  
**Gradle configurado no build automático:** 9.8.1

ECO é uma aventura de terror narrativo em português brasileiro. Você investiga uma transmissão ligada à antiga Estação Nilo. A exploração subterrânea aumenta a tensão, eventos atmosféricos interrompem a rotina e gravações sonoras revelam partes da história. O prólogo termina com três decisões diferentes.

## Importante sobre este pacote

Este arquivo contém o **projeto-fonte**, não um JAR já compilado. A máquina usada para preparar os arquivos tem Java 21 e não consegue baixar dependências pela rede, então não foi possível executar uma compilação local real. O projeto foi alinhado com o modelo oficial do Fabric para Minecraft 26.3 e inclui um workflow do GitHub Actions que usa Java 25 e Gradle para compilar e disponibilizar o JAR. **A compilação ainda precisa ser confirmada pelo primeiro resultado verde desse workflow**; não estou marcando o projeto como compilado antes disso.

## Como obter o JAR sem instalar ferramentas de programação

1. Crie um repositório no GitHub. Pode ser privado.
2. Envie para esse repositório os arquivos e pastas desta pasta extraída, mantendo a estrutura — principalmente `.github/workflows/build.yml`, `src`, `build.gradle`, `settings.gradle` e `gradle.properties`. Não envie apenas o ZIP dentro do repositório.
3. Quando o GitHub terminar o envio, abra a aba **Actions** e selecione **Compilar ECO para Minecraft 26.3**. O workflow também inicia automaticamente após um envio para `main` ou `master`; se necessário, use **Run workflow**.
4. Abra a execução concluída e baixe o artefato **ECO-A-Ultima-Transmissao-Minecraft-26.3**. Dentro dele estará o JAR instalável.
5. Coloque esse JAR em `.minecraft/mods` junto com uma versão do **Fabric API compatível com Minecraft 26.3**. O Fabric Loader precisa estar instalado para a mesma versão do jogo.

Se o workflow ficar vermelho, abra a execução e veja a primeira etapa com erro. Isso dará a mensagem real do compilador, em vez de adivinhar ou instalar um arquivo que talvez não funcione.

## Começar a jogar

Crie um mundo novo ou faça backup do mundo antes de testar. Ative os comandos/cheats do mundo e use no chat:

- `/eco iniciar` — inicia o prólogo e toca a primeira gravação.
- `/eco objetivo` — mostra a etapa atual, progresso e nível de tensão.
- `/eco pista` — oferece uma dica contextual sem entregar toda a história.
- `/eco sinal` — reproduz o segundo registro após recolher 12 amostras subterrâneas.
- `/eco investigar` — interpreta oito amostras recolhidas em profundidade (Y -20 ou menos).
- `/eco final selar` — encerra a frequência.
- `/eco final fugir` — abandona a investigação e foge.
- `/eco final responder` — responde à transmissão.
- `/eco ajuda` — lista os comandos.

### Como o prólogo progride

1. Explore o subterrâneo do Mundo Superior e quebre 12 blocos de pedra, ardósia ou minério para recolher amostras.
2. Use `/eco sinal` e escute o Registro 02.
3. Desça até Y -20 ou menos e quebre oito blocos de investigação.
4. Use `/eco investigar` e escolha um dos três finais.

A tensão sobe com exploração profunda, mineração e eventos; ela diminui ao descansar perto da superfície. Eventos aleatórios incluem estática, marcas estranhas, transmissões interrompidas e passos no escuro. O efeito de escuridão é curto e não causa dano.

## Áudio

O pacote inclui quatro gravações faladas em português brasileiro e uma faixa de estática. As falas foram **sintetizadas localmente por texto-para-fala** e tratadas com efeitos para criar o som de um gravador antigo; não são dublagem humana. Os nomes das faixas e as legendas estão em português.

## O que está implementado nesta versão

- Campanha individual salva nos dados do mundo, incluindo etapa, amostras, tensão e final escolhido.
- Objetivos sequenciais, pistas contextuais e três desfechos de prólogo.
- Áudio original sintetizado, eventos de ambiente e efeito breve de escuridão.
- Tensão dinâmica; os eventos são espaçados e a categoria global do evento não se repete duas vezes seguidas.
- Textos e legendas de recursos em `pt_br`.
- Compilação automatizada com artefato JAR para baixar.

## O que ainda falta antes de chamar ECO de “mod completo”

Ainda não existem entidades próprias com IA, estruturas geradas no mundo, minério ou ferramenta registrada, diário com interface gráfica, combate próprio nem os capítulos posteriores ao prólogo. Os eventos atuais usam efeitos e som; eles não simulam ainda uma criatura física seguindo o jogador. Isso fica explicitado para que o escopo não seja confundido com o conteúdo da história planejada.

## Referências de desenvolvimento

A configuração usa os números publicados no seletor oficial de versões do Fabric para 26.3: Fabric Loader 0.19.5, Fabric API 0.164.0+26.3 e Loom 1.18-SNAPSHOT. A versão 26.x não usa a linha antiga de mapeamentos Yarn/Official no `build.gradle` como os projetos mais antigos.
