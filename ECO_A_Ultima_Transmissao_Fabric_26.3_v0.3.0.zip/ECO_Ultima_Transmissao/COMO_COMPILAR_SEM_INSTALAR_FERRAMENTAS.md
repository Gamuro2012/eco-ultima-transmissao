# Como obter a compilação do ECO usando só o navegador

O ZIP tem código-fonte, sons e o workflow automático. Para que o GitHub execute o compilador, o projeto precisa estar nos arquivos de um repositório; guardar o ZIP como um arquivo único não executa o workflow.

1. Entre no GitHub e crie um repositório novo (privado serve).
2. Abra **Add file → Upload files**. Envie o conteúdo da pasta extraída, mantendo `.github/workflows` e `src` como pastas no repositório. Se o navegador não aceitar uma pasta inteira, envie os arquivos em lotes sem mudar a estrutura. Depois clique em **Commit changes**.
3. Abra **Actions** e selecione **Compilar ECO para Minecraft 26.3**. A compilação também é iniciada automaticamente após o commit.
4. Abra a execução. Se ela ficar verde, baixe o artefato `ECO-A-Ultima-Transmissao-Minecraft-26.3` na área **Artifacts**.
5. Extraia o artefato e copie o JAR que não termina em `-sources.jar` para a pasta `mods` do Minecraft 26.3 com Fabric instalado e Fabric API compatível.

Se a execução falhar, não instale JARs de outra versão. O texto da primeira etapa com erro é o diagnóstico real a corrigir no projeto.
