# ECO: A Última Transmissão — lore e plano de jogo

## Premissa

Em 1998, a Estação Nilo perfurou uma formação rochosa que não aparecia em nenhum mapa geológico. Durante dezessete minutos, os rádios da região transmitiram vozes de pessoas que ainda não haviam desaparecido. A equipe lacrou o acesso. Anos depois, uma nova expedição encontra o sinal novamente.

## Prólogo implementado na versão 0.3.0

### Etapa 1 — O ruído
- O jogador inicia a investigação com `/eco iniciar`.
- Recolhe 12 amostras de pedra ou minério subterrâneo.
- Eventos e sinais ambientais elevam a tensão e introduzem a voz do gravador.

### Etapa 2 — Frequência 03:17
- O comando `/eco sinal` toca o segundo registro e revela que uma porta foi encontrada trancada por dentro.
- O jogador precisa descer a Y -20 ou menos e recolher oito amostras de pedra/minério.

### Etapa 3 — A porta por dentro
- `/eco investigar` libera o Registro 03.
- O jogador escolhe entre selar a frequência, fugir com a própria vida ou responder.
- A escolha fica salva por jogador nos dados do mundo.

## Entidades planejadas — ainda não implementadas como criaturas

- **O Repetidor:** imita padrões de som; aprende onde o jogador costuma se sentir seguro.
- **O Vigia Cego:** patrulha túneis; reage à mineração repetida e à luz intensa.
- **A Fenda:** manifestação ambiental que altera caminhos e apaga sinais.
- **O Técnico Nilo:** presença ambígua que fornece instruções parcialmente contraditórias.

Esses elementos são parte do plano narrativo, não mobs que existam no JAR atual.

## Sistemas planejados para versões futuras

- Minério de ressonita, item sintonizador e ferramenta de leitura de ecos.
- Entidades com IA exclusiva e pistas sonoras claras antes de uma perseguição.
- Estruturas subterrâneas e uma câmara de investigação geradas no mundo.
- Diário com interface gráfica, coleta de documentos e escolhas persistentes.
- Capítulos adicionais com finais ramificados além do prólogo.

## Regras de atmosfera

- O perigo deve ser anunciado por pistas de áudio e mensagens antes de se tornar ameaçador.
- Nem todo evento causa dano; o silêncio e a incerteza fazem parte do ritmo.
- Eventos não devem repetir a mesma categoria consecutivamente.
- Deve haver pausas seguras para o jogador ler as pistas.
- Textos e legendas devem permanecer em português brasileiro.
