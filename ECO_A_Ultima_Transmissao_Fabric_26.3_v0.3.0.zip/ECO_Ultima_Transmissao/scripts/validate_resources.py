#!/usr/bin/env python3
"""Fast pre-build checks for ECO's Minecraft resource files."""

from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RES = ROOT / "src" / "main" / "resources"
MOD_ID = "eco_ultima_transmissao"
LANG_FILE = RES / "assets" / MOD_ID / "lang" / "pt_br.json"
SOUNDS_FILE = RES / "assets" / MOD_ID / "sounds.json"


def read_json(path: Path):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:  # JSON decode errors should be actionable in CI.
        raise SystemExit(f"ERRO: JSON inválido em {path.relative_to(ROOT)}: {exc}") from exc


def main() -> int:
    metadata = read_json(RES / "fabric.mod.json")
    if metadata.get("id") != MOD_ID:
        raise SystemExit(f"ERRO: id do mod deveria ser {MOD_ID!r}.")
    if "br.guilherme.eco.EcoMod" not in metadata.get("entrypoints", {}).get("main", []):
        raise SystemExit("ERRO: entrypoint principal do mod não foi encontrado no fabric.mod.json.")

    lang = read_json(LANG_FILE)
    sounds = read_json(SOUNDS_FILE)
    problems: list[str] = []

    for event_name, config in sounds.items():
        subtitle = config.get("subtitle")
        if subtitle and subtitle not in lang:
            problems.append(f"legenda sem tradução pt_BR: {subtitle}")

        sound_entries = config.get("sounds", [])
        if not sound_entries:
            problems.append(f"evento sem arquivos de áudio: {event_name}")

        for entry in sound_entries:
            if isinstance(entry, str):
                sound_id = entry
            elif isinstance(entry, dict):
                sound_id = entry.get("name", "")
            else:
                problems.append(f"entrada de áudio não reconhecida em {event_name}")
                continue

            namespace, separator, path = sound_id.partition(":")
            if not separator:
                namespace, path = MOD_ID, sound_id
            if namespace != MOD_ID:
                # Vanilla sounds are valid references too; no local file is expected.
                continue
            audio_path = RES / "assets" / MOD_ID / "sounds" / f"{path}.ogg"
            if not audio_path.is_file():
                problems.append(f"arquivo de áudio ausente: {audio_path.relative_to(ROOT)}")
            elif not audio_path.read_bytes().startswith(b"OggS"):
                problems.append(f"arquivo não parece ser OGG: {audio_path.relative_to(ROOT)}")

    if problems:
        print("Falha na validação dos recursos do ECO:")
        for problem in problems:
            print(f" - {problem}")
        return 1

    print(f"OK: metadados do mod, {len(sounds)} eventos de áudio e legendas pt_BR validados.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
