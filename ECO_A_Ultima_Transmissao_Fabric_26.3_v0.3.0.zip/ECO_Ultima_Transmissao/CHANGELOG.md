# Histórico de versões

## 0.3.0 — base de campanha e áudio

- Progresso da campanha guardado em dados do mundo, separado por jogador.
- Prólogo com objetivos encadeados, amostras subterrâneas, investigação profunda e três finais.
- Tensão dinâmica e eventos atmosféricos com intervalos variados e categoria sem repetição consecutiva.
- Quatro gravações sintetizadas em pt-BR e um som de estática, com legendas localizadas.
- Gradle ajustado à geração 26.x do Fabric e workflow GitHub Actions para gerar o JAR.
- Validador automático dos metadados, arquivos OGG e traduções dos sons.
- Ainda sem compilação confirmada ou teste dentro do cliente Minecraft neste ambiente.

## Correção de compilação (22/10/2026)
- Ajustado o modo de repositórios do Gradle para permitir o repositório temporário que o Fabric Loom cria durante a configuração.
- Mantida a validação automatizada dos metadados, sons e traduções em pt_BR.


## 0.3.2 — correção de compilação
- Atualizado o acesso ao servidor para `ServerPlayer.level().getServer()`, compatível com a API do Minecraft 26.3.
- Ajustada a versão do projeto para 0.3.2.
