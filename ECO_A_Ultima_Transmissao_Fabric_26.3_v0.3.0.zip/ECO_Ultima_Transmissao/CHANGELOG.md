# Histórico de versões

## 0.3.0 — base de campanha e áudio

- Progresso da campanha guardado em dados do mundo, separado por jogador.
- Prólogo com objetivos encadeados, amostras subterrâneas, investigação profunda e três finais.
- Tensão dinâmica e eventos atmosféricos com intervalos variados e categoria sem repetição consecutiva.
- Quatro gravações sintetizadas em pt-BR e um som de estática, com legendas localizadas.
- Gradle ajustado à geração 26.x do Fabric e workflow GitHub Actions para gerar o JAR.
- Validador automático dos metadados, arquivos OGG e traduções dos sons.
- Ainda sem compilação confirmada ou teste dentro do cliente Minecraft neste ambiente.
