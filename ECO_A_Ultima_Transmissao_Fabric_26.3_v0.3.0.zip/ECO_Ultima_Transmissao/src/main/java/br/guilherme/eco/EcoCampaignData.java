package br.guilherme.eco;

import com.mojang.serialization.Codec;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;
import net.minecraft.world.level.saveddata.SavedDataType;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Saves each player's campaign profile into the world's normal saved-data storage. */
public final class EcoCampaignData extends SavedData {
    private final Map<String, String> values;

    private static final Codec<EcoCampaignData> CODEC = Codec.unboundedMap(Codec.STRING, Codec.STRING)
            .xmap(EcoCampaignData::new, data -> new HashMap<>(data.values));

    private static final SavedDataType<EcoCampaignData> TYPE = new SavedDataType<>(
            EcoMod.id("campaign"), EcoCampaignData::new, CODEC, null
    );

    public EcoCampaignData() {
        this.values = new HashMap<>();
    }

    private EcoCampaignData(Map<String, String> values) {
        this.values = new HashMap<>(values);
    }

    public static EcoCampaignData get(MinecraftServer server) {
        ServerLevel overworld = server.getLevel(ServerLevel.OVERWORLD);
        if (overworld == null) {
            return new EcoCampaignData();
        }
        return overworld.getDataStorage().computeIfAbsent(TYPE);
    }

    public int getInt(UUID player, String key, int fallback) {
        try {
            return Integer.parseInt(values.getOrDefault(makeKey(player, key), Integer.toString(fallback)));
        } catch (NumberFormatException ignored) {
            return fallback;
        }
    }

    public String getString(UUID player, String key, String fallback) {
        return values.getOrDefault(makeKey(player, key), fallback);
    }

    public void setInt(UUID player, String key, int value) {
        values.put(makeKey(player, key), Integer.toString(value));
        setDirty();
    }

    public void setString(UUID player, String key, String value) {
        values.put(makeKey(player, key), value);
        setDirty();
    }

    public int addInt(UUID player, String key, int amount, int fallback) {
        int result = getInt(player, key, fallback) + amount;
        setInt(player, key, result);
        return result;
    }

    private static String makeKey(UUID player, String key) {
        return player + "." + key;
    }
}
