package br.guilherme.eco;

import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.sounds.SoundEvent;

/** Registered sound events used by the Portuguese recordings and atmosphere. */
public final class EcoSounds {
    public static final SoundEvent ESTATICA = register("estatica");
    public static final SoundEvent REGISTRO_01 = register("registro_01");
    public static final SoundEvent REGISTRO_02 = register("registro_02");
    public static final SoundEvent REGISTRO_03 = register("registro_03");
    public static final SoundEvent SUSSURRO = register("sussurro");

    private EcoSounds() { }

    private static SoundEvent register(String path) {
        Identifier id = EcoMod.id(path);
        return Registry.register(BuiltInRegistries.SOUND_EVENT, id, SoundEvent.createVariableRangeEvent(id));
    }

    public static void init() {
        // Referencing this method ensures this class is loaded during mod initialization.
    }
}
