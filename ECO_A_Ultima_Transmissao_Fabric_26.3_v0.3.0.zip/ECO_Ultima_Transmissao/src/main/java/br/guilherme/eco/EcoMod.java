package br.guilherme.eco;

import com.mojang.brigadier.Command;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.minecraft.commands.Commands;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;

import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

public final class EcoMod implements ModInitializer {
    public static final String MOD_ID = "eco_ultima_transmissao";

    private static int tickCounter = 0;
    private static int eventCountdown = 20 * 100;
    private static int lastWorldEvent = -1;

    @Override
    public void onInitialize() {
        EcoSounds.init();
        registerCommands();
        registerGameplayEvents();
    }

    public static Identifier id(String path) {
        return Identifier.fromNamespaceAndPath(MOD_ID, path);
    }

    private static void registerGameplayEvents() {
        PlayerBlockBreakEvents.AFTER.register((level, player, pos, state, blockEntity) -> {
            if (!(player instanceof ServerPlayer sp) || level.isClientSide()) return;
            if (!sp.level().dimension().equals(ServerLevel.OVERWORLD)) return;
            if (sp.isCreative() || sp.isSpectator()) return;

            EcoCampaignData data = EcoCampaignData.get(sp.level().getServer());
            int chapter = data.getInt(sp.getUUID(), "chapter", 0);
            if (chapter < 1 || chapter > 3) return;

            String blockPath = BuiltInRegistries.BLOCK.getKey(state.getBlock()).toString();
            if (!isInvestigationBlock(blockPath)) return;

            if (chapter == 1 && sp.getY() < 50) {
                int mined = data.getInt(sp.getUUID(), "surface_samples", 0);
                if (mined < 12) {
                    mined = data.addInt(sp.getUUID(), "surface_samples", 1, 0);
                    addTension(data, sp, 2);
                    if (mined == 3) tell(sp, "§8[Gravador] §7Três impactos registrados. O terceiro veio de trás de você.");
                    if (mined == 7) tell(sp, "§8[Gravador] §7A gravação contém uma voz que não estava lá antes.");
                    if (mined == 12) {
                        tell(sp, "§6[Objetivo atualizado] §fAmostras recolhidas. Volte a ouvir o gravador com §e/eco sinal§f.");
                        play(sp, EcoSounds.ESTATICA, 0.7F, 0.7F);
                    }
                }
            } else if (chapter == 2 && sp.getY() <= -20) {
                int deep = data.getInt(sp.getUUID(), "deep_samples", 0);
                if (deep < 8) {
                    deep = data.addInt(sp.getUUID(), "deep_samples", 1, 0);
                    addTension(data, sp, 3);
                    if (deep == 3) tell(sp, "§8[Interferência] §7...a porta não estava aqui ontem...");
                    if (deep == 6) {
                        tell(sp, "§4Você percebe marcas recentes na pedra. Elas acompanham seu caminho.");
                        play(sp, EcoSounds.SUSSURRO, 0.85F, 0.85F);
                    }
                    if (deep == 8) tell(sp, "§6[Objetivo atualizado] §fAs amostras profundas formam um padrão. Use §e/eco investigar§f.");
                }
            }
        });

        ServerTickEvents.END_SERVER_TICK.register(server -> {
            tickCounter++;
            if (tickCounter % 20 == 0) {
                for (ServerPlayer player : server.getPlayerList().getPlayers()) {
                    runAmbientChecks(player, server);
                }
            }
            if (tickCounter % 200 == 0) {
                for (ServerPlayer player : server.getPlayerList().getPlayers()) {
                    changeTensionOverTime(player, server);
                }
            }
            eventCountdown--;
            if (eventCountdown <= 0) {
                triggerWorldEvent(server);
                eventCountdown = 20 * (180 + ThreadLocalRandom.current().nextInt(180));
            }
        });
    }

    private static boolean isInvestigationBlock(String path) {
        return path.contains("stone") || path.contains("deepslate") || path.contains("ore")
                || path.contains("gravel") || path.contains("tuff") || path.contains("calcite");
    }

    private static void registerCommands() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
            dispatcher.register(Commands.literal("eco")
                .then(Commands.literal("iniciar").executes(ctx -> {
                    ServerPlayer p = ctx.getSource().getPlayerOrException();
                    EcoCampaignData data = EcoCampaignData.get(p.level().getServer());
                    int chapter = data.getInt(p.getUUID(), "chapter", 0);
                    if (chapter == 0) {
                        data.setInt(p.getUUID(), "chapter", 1);
                        data.setInt(p.getUUID(), "surface_samples", 0);
                        data.setInt(p.getUUID(), "deep_samples", 0);
                        data.setInt(p.getUUID(), "tension", 0);
                        tell(p, "§8§lECO — A ÚLTIMA TRANSMISSÃO");
                        tell(p, "§7Registro recuperado da antiga Estação Nilo. Data ilegível. Frequência: 03:17.");
                        tell(p, "§fObjetivo 1: explore o subterrâneo e recolha 12 amostras de pedra ou minério.");
                        tell(p, "§7Preste atenção nos sons. Algumas mensagens só aparecem depois de certos sinais.");
                        play(p, EcoSounds.REGISTRO_01, 0.95F, 0.92F);
                    } else {
                        tell(p, "§8[ECO] §7Sua investigação já está registrada. Consulte §f/eco objetivo§7.");
                    }
                    return Command.SINGLE_SUCCESS;
                }))
                .then(Commands.literal("objetivo").executes(ctx -> {
                    ServerPlayer p = ctx.getSource().getPlayerOrException();
                    EcoCampaignData data = EcoCampaignData.get(p.level().getServer());
                    int chapter = data.getInt(p.getUUID(), "chapter", 0);
                    int surface = data.getInt(p.getUUID(), "surface_samples", 0);
                    int deep = data.getInt(p.getUUID(), "deep_samples", 0);
                    int tension = data.getInt(p.getUUID(), "tension", 0);
                    tell(p, "§8§lECO — DIÁRIO DE CAMPO");
                    tell(p, "§7Tensão: " + tension + "/100");
                    switch (chapter) {
                        case 0 -> tell(p, "§fPrólogo: use §e/eco iniciar§f para começar a investigação.");
                        case 1 -> {
                            tell(p, "§fObjetivo: amostras subterrâneas — §e" + Math.min(surface, 12) + "/12");
                            if (surface >= 12) tell(p, "§aPróximo passo: §fuse §e/eco sinal§f para ouvir a gravação recuperada.");
                        }
                        case 2 -> {
                            tell(p, "§fObjetivo: investigar a frequência em profundidade — §e" + Math.min(deep, 8) + "/8");
                            if (deep >= 8) tell(p, "§aPróximo passo: use §e/eco investigar§f para interpretar as amostras.");
                        }
                        case 3 -> tell(p, "§fObjetivo final: decida o destino do sinal com §e/eco final selar§f, §e/eco final fugir§f ou §e/eco final responder§f.");
                        default -> tell(p, "§aPrólogo concluído. §7Escolha registrada: §f" + data.getString(p.getUUID(), "ending", "desconhecida") + "§7.");
                    }
                    return Command.SINGLE_SUCCESS;
                }))
                .then(Commands.literal("sinal").executes(ctx -> {
                    ServerPlayer p = ctx.getSource().getPlayerOrException();
                    EcoCampaignData data = EcoCampaignData.get(p.level().getServer());
                    int chapter = data.getInt(p.getUUID(), "chapter", 0);
                    int surface = data.getInt(p.getUUID(), "surface_samples", 0);
                    if (chapter != 1) {
                        tell(p, "§7O gravador não tem um novo registro disponível agora. Consulte §f/eco objetivo§7.");
                        return 0;
                    }
                    if (surface < 12) {
                        tell(p, "§cO sinal está incompleto: §f" + surface + "/12§c amostras recolhidas.");
                        return 0;
                    }
                    data.setInt(p.getUUID(), "chapter", 2);
                    tell(p, "§8§lREGISTRO 02 — 03:17");
                    tell(p, "§7«A equipe encontrou uma porta sob a ardósia. Ela estava trancada por dentro.»");
                    tell(p, "§7«O técnico Nilo ouviu a mãe chamando. Ela morreu onze anos antes da expedição.»");
                    tell(p, "§fNovo objetivo: desça até Y -20 ou menos e recolha oito amostras do mesmo padrão.");
                    play(p, EcoSounds.REGISTRO_02, 1.0F, 0.88F);
                    return Command.SINGLE_SUCCESS;
                }))
                .then(Commands.literal("investigar").executes(ctx -> {
                    ServerPlayer p = ctx.getSource().getPlayerOrException();
                    EcoCampaignData data = EcoCampaignData.get(p.level().getServer());
                    int chapter = data.getInt(p.getUUID(), "chapter", 0);
                    int deep = data.getInt(p.getUUID(), "deep_samples", 0);
                    if (chapter != 2 || deep < 8) {
                        tell(p, "§7Ainda faltam evidências para interpretar a frequência. Consulte §f/eco objetivo§7 e §f/eco pista§7.");
                        return 0;
                    }
                    data.setInt(p.getUUID(), "chapter", 3);
                    tell(p, "§8§lREGISTRO 03 — A PORTA POR DENTRO");
                    tell(p, "§7«A voz no rádio não prevê o futuro. Ela repete algo que já aconteceu — em outro lugar.»");
                    tell(p, "§7Você encontra três respostas possíveis no ruído: selar, fugir ou responder.");
                    tell(p, "§fEscolha seu desfecho: §e/eco final selar§f, §e/eco final fugir§f ou §e/eco final responder§f.");
                    play(p, EcoSounds.REGISTRO_03, 1.0F, 0.9F);
                    return Command.SINGLE_SUCCESS;
                }))
                .then(Commands.literal("pista").executes(ctx -> {
                    ServerPlayer p = ctx.getSource().getPlayerOrException();
                    EcoCampaignData data = EcoCampaignData.get(p.level().getServer());
                    int chapter = data.getInt(p.getUUID(), "chapter", 0);
                    int surface = data.getInt(p.getUUID(), "surface_samples", 0);
                    int deep = data.getInt(p.getUUID(), "deep_samples", 0);
                    if (chapter == 0) tell(p, "§7[Pista] O primeiro registro está no gravador. Comece com §f/eco iniciar§7.");
                    else if (chapter == 1 && surface < 12) tell(p, "§7[Pista] A transmissão enfraquece quando você sobe. Investigue pedra e minério abaixo da superfície.");
                    else if (chapter == 1) tell(p, "§7[Pista] As primeiras amostras estão prontas. Use §f/eco sinal§7 para reproduzir a gravação.");
                    else if (chapter == 2 && deep < 8) tell(p, "§7[Pista] O padrão se intensifica abaixo de Y -20. Procure ardósia, pedra ou minério nas profundezas.");
                    else if (chapter == 2) tell(p, "§7[Pista] Você tem amostras suficientes. Use §f/eco investigar§7 para interpretar o registro.");
                    else if (chapter == 3) tell(p, "§7[Pista] Nenhum dos finais é apresentado como certo. Decida com base no que os três registros lhe contaram.");
                    else tell(p, "§7[Pista] O sinal foi encerrado para você. Uma nova investigação exige outro perfil de jogador.");
                    return Command.SINGLE_SUCCESS;
                }))
                .then(Commands.literal("final")
                    .then(Commands.literal("selar").executes(ctx -> chooseEnding(ctx.getSource().getPlayerOrException(), "selar")))
                    .then(Commands.literal("fugir").executes(ctx -> chooseEnding(ctx.getSource().getPlayerOrException(), "fugir")))
                    .then(Commands.literal("responder").executes(ctx -> chooseEnding(ctx.getSource().getPlayerOrException(), "responder")))
                    .executes(ctx -> {
                        tell(ctx.getSource(), "§7Escolha: §f/eco final selar§7, §f/eco final fugir§7 ou §f/eco final responder§7.");
                        return Command.SINGLE_SUCCESS;
                    }))
                .then(Commands.literal("ajuda").executes(ctx -> {
                    tell(ctx.getSource(), "§8[ECO] §7Comandos: §f/eco iniciar§7, §f/eco objetivo§7, §f/eco sinal§7, §f/eco investigar§7, §f/eco pista§7, §f/eco final§7.");
                    tell(ctx.getSource(), "§7Seu progresso é guardado no mundo. Eventos e tensão são mais ativos no subterrâneo.");
                    return Command.SINGLE_SUCCESS;
                }))
            )
        );
    }

    private static int chooseEnding(ServerPlayer p, String ending) {
        EcoCampaignData data = EcoCampaignData.get(p.level().getServer());
        int chapter = data.getInt(p.getUUID(), "chapter", 0);
        if (chapter < 3) {
            tell(p, "§cVocê ainda não reuniu provas suficientes para escolher o destino do sinal. §7Use §f/eco objetivo§7.");
            return 0;
        }
        if (chapter >= 4) {
            tell(p, "§7Sua decisão já foi registrada: §f" + data.getString(p.getUUID(), "ending", "desconhecida") + "§7.");
            return 0;
        }
        data.setString(p.getUUID(), "ending", ending);
        data.setInt(p.getUUID(), "chapter", 4);
        tell(p, "§8§lDESFECHO — A ÚLTIMA TRANSMISSÃO");
        switch (ending) {
            case "selar" -> {
                tell(p, "§7Você fecha a frequência e enterra o gravador sob pedra. A voz ainda chama uma vez — depois, o silêncio permanece.");
                tell(p, "§aFinal: SILÊNCIO. §7A transmissão foi interrompida, mas a Estação Nilo continua sem explicação.");
            }
            case "fugir" -> {
                tell(p, "§7Você abandona as amostras e corre para a superfície. O ar parece normal outra vez, exceto pelo chiado no bolso vazio.");
                tell(p, "§eFinal: SOBREVIVENTE. §7Você escapou; o sinal não ficou para trás.");
            }
            default -> {
                tell(p, "§7Você responde. Por alguns segundos, escuta sua própria voz contando os acontecimentos antes de você vivê-los.");
                tell(p, "§4Final: REPETIDOR. §7A transmissão recebeu uma nova voz.");
                play(p, EcoSounds.SUSSURRO, 1.0F, 0.75F);
            }
        }
        tell(p, "§7Este é o encerramento do prólogo. Use §f/eco objetivo§7 para consultar o registro final.");
        return Command.SINGLE_SUCCESS;
    }

    private static void runAmbientChecks(ServerPlayer p, MinecraftServer server) {
        if (p.isCreative() || p.isSpectator() || !p.level().dimension().equals(ServerLevel.OVERWORLD)) return;
        EcoCampaignData data = EcoCampaignData.get(server);
        int chapter = data.getInt(p.getUUID(), "chapter", 0);
        if (chapter < 1 || chapter >= 4) return;

        int tension = data.getInt(p.getUUID(), "tension", 0);
        int chance = ThreadLocalRandom.current().nextInt(1000);
        if (p.getY() < 30 && chance < (tension >= 70 ? 5 : 2)) {
            tell(p, "§8[Eco distante] §7toc... toc... toc...");
            play(p, EcoSounds.ESTATICA, 0.55F, 0.65F);
            addTension(data, p, 1);
        } else if (p.getY() < 10 && chance >= 20 && chance < 23) {
            tell(p, "§8[Gravador] §7O ruído está mais perto agora. Não parece vir de um túnel.");
        }
    }

    private static void changeTensionOverTime(ServerPlayer p, MinecraftServer server) {
        if (p.isCreative() || p.isSpectator()) return;
        EcoCampaignData data = EcoCampaignData.get(server);
        int chapter = data.getInt(p.getUUID(), "chapter", 0);
        if (chapter < 1 || chapter >= 4) return;
        if (p.getY() < 35 && p.level().dimension().equals(ServerLevel.OVERWORLD)) addTension(data, p, 1);
        else if (p.getY() >= 55) addTension(data, p, -2);
    }

    private static void addTension(EcoCampaignData data, ServerPlayer p, int amount) {
        int current = data.getInt(p.getUUID(), "tension", 0);
        data.setInt(p.getUUID(), "tension", Math.max(0, Math.min(100, current + amount)));
    }

    private static void triggerWorldEvent(MinecraftServer server) {
        List<ServerPlayer> players = server.getPlayerList().getPlayers();
        if (players.isEmpty()) return;
        int event = ThreadLocalRandom.current().nextInt(4);
        if (event == lastWorldEvent) event = (event + 1 + ThreadLocalRandom.current().nextInt(3)) % 4;
        lastWorldEvent = event;

        for (ServerPlayer p : players) {
            if (p.isCreative() || p.isSpectator() || !p.level().dimension().equals(ServerLevel.OVERWORLD) || p.getY() > 48) continue;
            EcoCampaignData data = EcoCampaignData.get(server);
            int chapter = data.getInt(p.getUUID(), "chapter", 0);
            if (chapter < 1 || chapter >= 4) continue;

            switch (event) {
                case 0 -> {
                    tell(p, "§8§lEVENTO: ESTÁTICA");
                    tell(p, "§7O chiado parece se deslocar ao redor de você. Por um instante, os sons vêm do lado errado.");
                    play(p, EcoSounds.ESTATICA, 0.9F, 0.65F);
                    addTension(data, p, 5);
                }
                case 1 -> {
                    tell(p, "§8§lEVENTO: A MARCA");
                    tell(p, "§7Você encontra uma marca escura na pedra. A lembrança dela some quando tenta descrevê-la.");
                    addTension(data, p, 8);
                }
                case 2 -> {
                    tell(p, "§8§lEVENTO: FREQUÊNCIA PERDIDA");
                    tell(p, "§7«...não desça pelo poço. Nós fechamos a porta. NÓS FECHAMOS A PORTA.»");
                    play(p, EcoSounds.SUSSURRO, 0.8F, 0.9F);
                    addTension(data, p, 6);
                }
                default -> {
                    tell(p, "§8§lEVENTO: PASSOS NO ESCURO");
                    tell(p, "§7Há passos acompanhando os seus. Eles param quando você para.");
                    p.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 50, 0, false, false));
                    addTension(data, p, 10);
                }
            }
        }
    }

    private static void play(ServerPlayer p, net.minecraft.sounds.SoundEvent event, float volume, float pitch) {
        p.level().playSound(null, p.blockPosition(), event, SoundSource.AMBIENT, volume, pitch);
    }

    private static void tell(ServerPlayer player, String message) {
        player.sendSystemMessage(Component.literal(message));
    }

    private static void tell(net.minecraft.commands.CommandSourceStack source, String message) {
        source.sendSuccess(() -> Component.literal(message), false);
    }
}
